import re

with open(r'C:\2025\code\ImageFileServer\p2p-db\src\main\java\ds\DbFile.java', 'r', encoding='utf-8') as f:
    code = f.read()

# Fix saveMetadataGroup(..., "tags", ...)
code = code.replace('// saveMetadataGroup(metadata.globalFileId, "tags", metadata.tags); // 不再使用简单的序列化存储', 
                    'saveMetadataGroup(metadata.globalFileId, "tags", metadata.tags);')

# Fix metaStore.getData(indexId, "value") -> metaStore.getValueByIndexId(indexId)
code = code.replace('byte[] metaBytes = metaStore.getData(indexId, "value");',
                    'byte[] metaBytes = metaStore.getValueByIndexId(indexId);')

with open(r'C:\2025\code\ImageFileServer\p2p-db\src\main\java\ds\DbFile.java', 'w', encoding='utf-8') as f:
    f.write(code)
