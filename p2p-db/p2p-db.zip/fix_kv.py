import re

with open(r'C:\2025\code\ImageFileServer\p2p-db\src\main\java\ds\DbSha256KV.java', 'r', encoding='utf-8') as f:
    code = f.read()

new_method = """
    public byte[] getValueByIndexId(long indexId) throws IOException {
        byte[] indexBucketData = getData(indexId, "index");
        if (indexBucketData == null || indexBucketData.length < INDEX_FIXED_PART_SIZE) return null;
        
        int storedValueLen = DsDataUtil.loadInt(indexBucketData, INDEX_OFFSET_VALUE_LEN);
        long valueId = DsDataUtil.loadLong(indexBucketData, INDEX_OFFSET_VALUE_ID);
        
        byte[] valueBucketData = getData(valueId, "value");
        if (valueBucketData == null) return null;
        
        byte[] valueContent = new byte[storedValueLen];
        System.arraycopy(valueBucketData, 0, valueContent, 0, storedValueLen);
        return valueContent;
    }
"""

code = code.replace('public byte[] getData(long id, String type) throws IOException {', new_method + '\n    public byte[] getData(long id, String type) throws IOException {')

with open(r'C:\2025\code\ImageFileServer\p2p-db\src\main\java\ds\DbSha256KV.java', 'w', encoding='utf-8') as f:
    f.write(code)
