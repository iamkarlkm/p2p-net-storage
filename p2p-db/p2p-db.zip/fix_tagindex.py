import re

with open(r'C:\2025\code\ImageFileServer\p2p-db\src\main\java\ds\DbTagIndex.java', 'r', encoding='utf-8') as f:
    code = f.read()

code = code.replace(
    'byte[] nodeData = nodeStore.getData(currentNodeId, "value"); // 直接通过 ID 读取 Value',
    'byte[] nodeData = nodeStore.getValueByIndexId(currentNodeId); // 直接通过 ID 读取 Value'
)

with open(r'C:\2025\code\ImageFileServer\p2p-db\src\main\java\ds\DbTagIndex.java', 'w', encoding='utf-8') as f:
    f.write(code)
