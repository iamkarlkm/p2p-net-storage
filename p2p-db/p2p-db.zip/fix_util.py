import re

with open(r'C:\2025\code\ImageFileServer\p2p-db\src\main\java\ds\DsDataUtil.java', 'r', encoding='utf-8') as f:
    code = f.read()

# Change setBit(int, int) to return int
code = code.replace('public final static void setBit(int data, int n) {', 'public final static int setBit(int data, int n) {')
code = code.replace('data |= (1 << (31 - (n & 31)));', 'data |= (1 << (31 - (n & 31)));\n            return data;')

# Change clearBit(int, int) to return int
code = code.replace('public final static void clearBit(int data, int n) {', 'public final static int clearBit(int data, int n) {')
code = code.replace('data &= ~(1 << (31 - (n & 31)));', 'data &= ~(1 << (31 - (n & 31)));\n            return data;')

with open(r'C:\2025\code\ImageFileServer\p2p-db\src\main\java\ds\DsDataUtil.java', 'w', encoding='utf-8') as f:
    f.write(code)
