import re

with open(r'C:\2025\code\ImageFileServer\p2p-db\src\main\java\ds\DsHashSet.java', 'r', encoding='utf-8') as f:
    code = f.read()

# Fix mask
code = code.replace(
    'private int[] levelsMask = new int[]{0xf,0xffc,0xffc,0xffc,0xffc,0xffc,0xffc};//哈希掩码',
    'private int[] levelsMask = new int[]{0xf,0x3ff,0x3ff,0x3ff,0x3ff,0x3ff,0x3ff};//哈希掩码'
)

# Fix bits extraction
helpers = """
    private static int getHasValue(int data, int start, int count) {
        int shift = 32 - start - count;
        return (data >>> shift) & ((1 << count) - 1);
    }
"""

code = code.replace('private static final int calcDataAreaSize', helpers + '\n    private static final int calcDataAreaSize')

code = re.sub(r'DsDataUtil\.bitsToInt\(([^,]+),\s*([^,]+),\s*([^)]+)\)', r'getHasValue(\1, \2, \3)', code)

# Fix setBit/clearBit usage for isHasValue
code = re.sub(r'DsDataUtil\.setBit\(([^,]+),\s*([^)]+)\);', r'\1 = DsDataUtil.setBit(\1, \2);', code)
code = re.sub(r'DsDataUtil\.clearBit\(([^,]+),\s*([^)]+)\);', r'\1 = DsDataUtil.clearBit(\1, \2);', code)

# Fix size calculations in updateValues
code = code.replace(
    'long baseNext = updateHeaderWithOldValue(nextLevel, 0, areaSize+headSize, hash, value);',
    'long baseNext = updateHeaderWithOldValue(nextLevel, 0, levelsAreaSize[nextLevel]+levelsHeadSize[nextLevel], hash, value);'
)

code = code.replace(
    'long baseNew = updateHeaderWithOldValue(level,1, areaSize+headSize,hash,value);',
    'int nextLvl = level + 1;\n                    long baseNew = updateHeaderWithOldValue(level,1, levelsAreaSize[nextLvl]+levelsHeadSize[nextLvl],hash,value);'
)

code = code.replace(
    'return updateValues(baseNew,level,hash,areaSize,headSize,value,oldValue);',
    'return updateValues(baseNew,level,hash,levelsAreaSize[nextLvl],levelsHeadSize[nextLvl],value,oldValue);'
)

code = code.replace(
    'long base = updateHeaderWithOldValue(level, 1, areaSize+headSize, hash, value);',
    'int nextLvl = level + 1;\n                    long base = updateHeaderWithOldValue(level, 1, levelsAreaSize[nextLvl]+levelsHeadSize[nextLvl], hash, value);'
)

code = code.replace(
    'return updateValues(base, level, hash, areaSize, headSize, value, oldValue);',
    'return updateValues(base, level, hash, levelsAreaSize[nextLvl], levelsHeadSize[nextLvl], value, oldValue);'
)

with open(r'C:\2025\code\ImageFileServer\p2p-db\src\main\java\ds\DsHashSet.java', 'w', encoding='utf-8') as f:
    f.write(code)
